package biblioteca;

import java.util.Scanner;

public class Libri {

    Libro[] Libreria = new Libro[50];
    public static int conta;

    Scanner input = new Scanner(System.in);

    // Metodo 1
    //  Comparare libri
    public int compareBookObjects(Libro b1, Libro b2) {

        // Se il nome del Libro corrisponde
        if (b1.TitoloLibro.equalsIgnoreCase(b2.TitoloLibro)) {

            // Stampa Libro esistente
            System.out.println(
                    "Il nome di questo libro è gia esistente.");
            return 0;
        }

        // se il seriale del Libro corrisponde
        if (b1.sNo == b2.sNo) {

            // Stampi Libro esistente
            System.out.println(
                    "Il numero seriale di questo libro è gia esistente.");

            return 0;
        }
        return 1;
    }

    // Metodo 2
    // Aggiungere libro
    public void AggiungiLibro(Libro b) {

        for (int i = 0; i < conta; i++) {

            if (this.compareBookObjects(b, this.Libreria[i])
                    == 0) {
                return;
            }
        }

        if (conta < 50) {

            Libreria[conta] = b;
            conta++;
        } else {

            System.out.println(
                    "Spazio insufficiente per aggiungere altri libri.");
        }
    }

    // Metodo 3
    // Cercare Libro con numero Seriale
    public void RicercaSNo() {

        System.out.println(
                "\t\t\t\tCERCA DAL NUMERO SERIALE\n");

        int sNo;
        System.out.println("Inserisci il numero seriale del libro:");
        sNo = input.nextInt();

        int flag = 0;
        System.out.println(
                "Numero Seriale\t\tNome\t\tAutore\t\tQuantità Disponibile\t\tQuantità Totale");

        for (int i = 0; i < conta; i++) {
            if (sNo == Libreria[i].sNo) {
                System.out.println(Libreria[i].sNo + "\t\t"
                        + Libreria[i].TitoloLibro + "\t\t"
                        + Libreria[i].AutoreLibro + "\t\t"
                        + Libreria[i].QuantitàCopieLibri + "\t\t"
                        + Libreria[i].QuantitàLibri);
                flag++;
                return;
            }
        }
        if (flag == 0) {
            System.out.println("Numero Libri per Numero Seriale "
                    + sNo + " Trovato.");
        }
    }

    // Metodo 4
    // Cercare nome Autore
    public void searchByAuthorName() {

        System.out.println(
                "\t\t\t\tRICERCA PER AUTORE");

        input.nextLine();

        System.out.println("Inserisci nome dell'autore:");
        String NomeAutore = input.nextLine();

        int flag = 0;

        System.out.println(
                "S.No\t\tNome\t\tAutore\t\tQuantità Disponibile\t\tQuantità Totale");

        for (int i = 0; i < conta; i++) {

            // se l'autore corrisponde a uno qualsiasi dei suoi Libri
            if (NomeAutore.equalsIgnoreCase(Libreria[i].AutoreLibro)) {

                // Print below corresponding credentials
                System.out.println(Libreria[i].sNo + "\t\t"
                        + Libreria[i].TitoloLibro + "\t\t"
                        + Libreria[i].AutoreLibro + "\t\t"
                        + Libreria[i].QuantitàCopieLibri + "\t\t"
                        + Libreria[i].QuantitàLibri);
                flag++;
            }
        }

        // Altrimenti nessun Libro corrisponde all'autore
        if (flag == 0) {
            System.out.println("No Books of " + NomeAutore
                    + " Found.");
        }
    }

    // Metodo 5
    // Per visualizzare tutti i Libri
    public void MostraLibri() {

        System.out.println("\t\t\t\tMOSTRA TUTTI I LIBRI\n");
        System.out.println(
                "S.No\t\tNome\t\tAutore\t\tQuantità Disponibile\t\tQuantità Totale");

        for (int i = 0; i < conta; i++) {

            System.out.println(Libreria[i].sNo + "\t\t"
                    + Libreria[i].TitoloLibro + "\t\t"
                    + Libreria[i].AutoreLibro + "\t\t"
                    + Libreria[i].QuantitàCopieLibri + "\t\t"
                    + Libreria[i].QuantitàLibri);
        }
    }

    // Metodo 6
    // Per modificare il Libro
    public void AumentaLibri() {

        System.out.println(
                "\t\t\t\tAUMENTI QUANTITA LIBRI\n");
        System.out.println("Inserisci il numero seriale del libro:");

        int sNo = input.nextInt();

        for (int i = 0; i < conta; i++) {

            if (sNo == Libreria[i].sNo) {

                System.out.println(
                        "Inserisci il numero delle copie dei libri aggiunti:");

                int QuantitàAgg = input.nextInt();
                Libreria[i].QuantitàLibri += QuantitàAgg;
                Libreria[i].QuantitàCopieLibri += QuantitàAgg;

                return;
            }
        }
    }

    // Metodo 7
    // Per creare il menu
    public void Menu() {

        // Mostra Menu
        System.out.println(
                "----------------------------------------------------------------------------------------------------------");
        System.out.println("Premere 1 Aggiungi un nuovo Libro.");
        System.out.println("Premere 0 Arrivederci!.");
        System.out.println(
                "Premere 2 Aumenta quantità delle copie dei libri.");
        System.out.println("Premere 3 Ricerca Libro.");
        System.out.println("Premere 4 Mostra tutti i Libri.");
        System.out.println("Premere 5 Registra nuovo Cliente.");
        System.out.println(
                "Premere 6 Mostra tutti i Clienti registrati.");
        System.out.println("Premere 7 Prendi in prestito un libro. ");
        System.out.println("Premere 8 Restituisci il libro");
        System.out.println(
                "-------------------------------------------------------------------------------------------------------");
    }

    // Metodo 8
    // Per cercare nella biblioteca
    public int Disponibilie(int sNo) {

        for (int i = 0; i < conta; i++) {
            if (sNo == Libreria[i].sNo) {
                if (Libreria[i].QuantitàCopieLibri > 0) {

                    System.out.println(
                            "Libro è disponibile.");
                    return i;
                }
                System.out.println("Libro NON è disponibile");
                return -1;
            }
        }

        System.out.println("No Book of Serial Number "
                + " Disponibile in Biblioteca.");
        return -1;
    }

    // Metodo 9
    // Per rimuovee un Libro dalla Libreria
    public Libro PrendiLibro() {

        System.out.println(
                "Inserisci il numero seriale del Libro da prendere in prestito.");
        int sNo = input.nextInt();

        int LibroIndice = Disponibilie(sNo);

        if (LibroIndice != -1) {
            Libreria[LibroIndice].QuantitàCopieLibri--;
            return Libreria[LibroIndice];
        }
        return null;
    }

    // Metodo 10
    // Aggiungere Libro alla LIbreria
    public void RestituisciLibro(Libro b) {
        for (int i = 0; i < conta; i++) {
            if (b.equals(Libreria[i])) {
                Libreria[i].QuantitàCopieLibri++;
                return;
            }
        }
    }
}