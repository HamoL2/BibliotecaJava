package biblioteca;

import java.awt.BorderLayout;
import java.awt.Font;
import java.util.Scanner;
import javax.swing.*;

public class Biblioteca {
 
    public static void main(String[] args)
    {
    	//Creo la finestra per l'interfaccia grafica
    	
    	JFrame finestra = new JFrame("Biblioteca");
    	finestra.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	finestra.setSize(1000, 1000);
    	finestra.setVisible(true);
    	
    	//Creo un pannello
    	
    	JPanel pannello = new JPanel();
    	finestra.add(pannello);
        
    	//Jlabel è un etichetta di testo che serve appunto per mostrare del testo sull applicazione.
    	JLabel titoloInterfaccia = new JLabel("Benvenuti nella nostra biblioteca");
    	titoloInterfaccia.setBounds(650, 20, 10, 200);
    	// Font serve per dare uno stile ad una frase o ad una parola
    	Font aspetto = new Font ("Serif" , Font.PLAIN , 25);
    	titoloInterfaccia.setFont(aspetto);
    	pannello.add(titoloInterfaccia);
    	
    	JLabel sottotitoloOpzioni = new JLabel("Seleziona una tra le seguenti opzioni: ");
    	sottotitoloOpzioni.setBounds(320 , 10 , 40 , 25);
    	pannello.add(sottotitoloOpzioni);
    	
    	
        // Creazione dell'oggetto della classe Scanner
        // per ricevere input dall'utente
        Scanner input = new Scanner(System.in);
 
        // Visualizzazione del menu
        System.out.println(
            "*******Benvenuto nella nostra Biblioteca!*******");
        System.out.println(
            "                  Seleziona una tra le seguenti opzioni:               ");
        System.out.println(
            "************************");
 
        // Creazione dell'oggetto della classe Libro
        Libri ob = new Libri();
        // Creazione dell'oggetto della classe Studenti
        Studenti obStudent = new Studenti();
 
        int choice;
        int searchChoice;
 
        // Creazione del menu
        // utilizzando il ciclo do- while
        do {
 
            ob.Menu();
            choice = input.nextInt();
 
            // Cambio Caso
            switch (choice) {
 
                // Caso
            case 1:
                Libro b = new Libro();
                ob.AggiungiLibro(b);
                break;
 
                // Caso
            case 2:
                ob.AumentaLibri();
                break;
 
            // Caso
            case 3:
 
                System.out.println(
                    " premere 1 per cercare con il numero di serie del libro.");
                System.out.println(
                    " Premere 2 per cercare con il nome dell'autore del libro.");
                searchChoice = input.nextInt();
 
                // switch
                switch (searchChoice) {
 
                    // Caso
                case 1:
                    ob.RicercaSNo();
                    break;
 
                    // Caso
                case 2:
                    ob.searchByAuthorName();
                }
                break;
 
                // Caso
            case 4:
                ob.MostraLibri();
                break;
 
                // Caso
            case 5:
                Studente s = new Studente();
                obStudent.AggiungiCliente(s);
                break;
 
                // Caso
            case 6:
                obStudent.MostraClienti();
                break;
 
                // Caso
            case 7:
                obStudent.PrendiLibro(ob);
                break;
 
                // Caso
            case 8:
                obStudent.RestituisciLibro(ob);
                break;
 
                // Caso predefinito che verrà eseguito sicuramente
                // se i casi precedenti non corrispondono
            default:
 
                // Stampa opzioni
                System.out.println("ENTER BETWEEN 0 TO 8.");
            }
 
        }
 

        while (choice != 0);
    }
}