package biblioteca;

import java.util.Scanner;
 
public class Studenti {
 
    // Creazione di oggetti di classe Scanner e Studenti
    Scanner input = new Scanner(System.in);
    Studente theStudents[] = new Studente[50];
 
    public static int conta = 0;
 
    // Metodo 1
    // Aggiungere libri
    public void AggiungiCliente(Studente s)
    {
        for (int i = 0; i < conta; i++) {
 
            if (s.RegNum.equalsIgnoreCase(theStudents[i].RegNum)) {
 
                // Print statement
                System.out.println(
                    "Student of Reg Num " + s.RegNum
                    + " è già esistente.");
 
                return;
            }
        }
 
        if (conta <= 50) {
            theStudents[conta] = s;
            conta++;
        }
    }
 
    // Metodo 2
    // Visualizzazione di tutti i Studenti
    public void MostraClienti()
    {
        // Stampa Nome e codice di registrazione
        System.out.println("Nome Cliente\t\tNumero Registrato");
        for (int i = 0; i < conta; i++) {
 
            System.out.println(theStudents[i].NomeStudente
                               + "\t\t"
                               + theStudents[i].RegNum);
        }
    }
 
    // Metodo 3
    // Per controllare lo Studente
    public int isStudent()
    {
        System.out.println("Inserisci il numero registrato:");
 
        String regNum = input.nextLine();
 
        for (int i = 0; i < conta; i++) {
 
            if (theStudents[i].RegNum.equalsIgnoreCase(
                    regNum)) {
                return i;
            }
        }
 
        System.out.println("Cliente non registrato.");
        System.out.println("Registrati.");
 
        return -1;
    }
 
    // Metodo 4
    // Per rimuovere un libro
    public void PrendiLibro(Libri libro)
    {
        int ClienteIndice = this.isStudent();
 
        if (ClienteIndice != -1) {
            System.out.println("Prendi in prestito");
 
            libro.MostraLibri();
            Libro b = libro.PrendiLibro();
 
            System.out.println("Prendi in prestito");
            if (b != null) {
 
                if (theStudents[ClienteIndice].ContaLibri
                    <= 5) {
 
                    System.out.println("Aggiungi un Libro");
                    theStudents[ClienteIndice].LibriInPrestito
                        [theStudents[ClienteIndice]
                             .ContaLibri]
                        = b;
                    theStudents[ClienteIndice].ContaLibri++;
 
                    return;
                }
                else {
 
                    System.out.println(
                        "Il Cliente non può prendere più di 5 libri.");
                    return;
                }
            }
            System.out.println("Libro non disponibile.");
        }
    }
 
    // Metodo 5
    // Aggiungere un libro
    public void RestituisciLibro(Libri libro)
    {
        int ClienteIndice = this.isStudent();
        if (ClienteIndice != -1) {
 
            // Stampa delle credenziali corrispondenti al Studente
            System.out.println(
                "S.No\t\t\tNome Libro\t\t\tNome Autore");
 
            Studente C = theStudents[ClienteIndice];
 
            for (int i = 0; i < C.ContaLibri; i++) {
 
                System.out.println(
                    C.LibriInPrestito[i].sNo + "\t\t\t"
                    + C.LibriInPrestito[i].TitoloLibro + "\t\t\t"
                    + C.LibriInPrestito[i].AutoreLibro);
            }
 
            System.out.println(
                "Inserisci il numero seriale del libro da prendere in prestito:");
 
            int sNo = input.nextInt();
 
            for (int i = 0; i < C.ContaLibri; i++) {
                if (sNo == C.LibriInPrestito[i].sNo) {
                    libro.RestituisciLibro(C.LibriInPrestito[i]);
                    C.LibriInPrestito[i] = null;
 
                    return;
                }
            }
 
            System.out.println("Numero di Serie " + sNo
                               + "Non trovato");
        }
    }
}