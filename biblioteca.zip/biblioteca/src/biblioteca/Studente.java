package biblioteca;

import java.util.Scanner;
 
public class Studente {
 
    // Variabili della classe
    String NomeStudente;
    String RegNum;
 
    Libro[] LibriInPrestito = new Libro[3];
    public int ContaLibri = 0; 
 
    // Creazione dell'oggetto della classe Scanner
    // Prende output dall'utente
    Scanner input = new Scanner(System.in);
 
    // Costruttore
    public Studente()
    {
        // Stampa
        System.out.println("Inserisci il tuo nome per la registrazione:");
 
        // 
        this.NomeStudente = input.nextLine();
 
        // Stampa
        System.out.println("Inserisci la password:");
        this.RegNum = input.nextLine();
    }
}