package biblioteca;
 
import java.util.Scanner;
 
public class Libro {
 
    public int sNo;
    public String TitoloLibro;
    public String AutoreLibro;
    public int QuantitàLibri;
    public int QuantitàCopieLibri;
 
    Scanner input = new Scanner(System.in);
 
    // Metod
    // Aggiugnere Dettagli del libro
    public Libro()
    {
        System.out.println("Inserisci il numero seriale del libro:");
        this.sNo = input.nextInt();
        input.nextLine();
 
        System.out.println("Inserisci il titolo del libro:");
        this.TitoloLibro = input.nextLine();
 
        System.out.println("Inserisci il nome dell'autore:");
        this.AutoreLibro = input.nextLine();
 
        System.out.println("Inserisci la quantità di libri:");
        this.QuantitàLibri = input.nextInt();
        QuantitàCopieLibri = this.QuantitàLibri;
    }
}